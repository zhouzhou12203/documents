<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

$dataFile = '12203data.json';
$entries = json_decode(file_get_contents($dataFile), true) ?? [];

// 过滤掉隐藏条目的真实文本
$filteredEntries = array_map(function ($entry) {
    if ($entry['hidden']) {
        // 不要发送真实的text，用空字符串代替或者完全删除
        $entry['text'] = ''; // 或者 unset($entry['text']);
    }
    return $entry;
}, $entries);

echo json_encode($filteredEntries, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
exit;
?>
